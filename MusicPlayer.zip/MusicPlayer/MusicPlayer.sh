#!/bin/bash
export LD_LIBRARY_PATH=$(dirname "$0")/lib:$LD_LIBRARY_PATH
export QT_QPA_PLATFORM_PLUGIN_PATH=$(dirname "$0")/plugins/
export QT_MULTIMEDIA_PLUGINS_PATH=$(dirname "$0")/plugins/mediaservice
/usr/local/MusicPlayer/MusicPlayer
